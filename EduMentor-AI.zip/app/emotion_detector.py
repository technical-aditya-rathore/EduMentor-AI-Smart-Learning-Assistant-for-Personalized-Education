def detect_emotion(image):
    # Here you can integrate OpenCV or pre-trained emotion model
    return "happy"  # Mock response
