from flask import Flask, render_template, request, jsonify
from app.chatbot import get_bot_response
from app.recommender import recommend_topics
from app.emotion_detector import detect_emotion

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json["message"]
    response = get_bot_response(user_input)
    return jsonify({"response": response})

@app.route("/recommend", methods=["POST"])
def recommend():
    subject = request.json["subject"]
    topics = recommend_topics(subject)
    return jsonify({"topics": topics})

@app.route("/emotion", methods=["POST"])
def emotion():
    image_data = request.files["image"]
    emotion = detect_emotion(image_data)
    return jsonify({"emotion": emotion})

if __name__ == "__main__":
    app.run(debug=True)
