def recommend_topics(subject):
    topics = {
        "math": ["Algebra", "Geometry", "Calculus"],
        "science": ["Physics", "Chemistry", "Biology"],
        "english": ["Grammar", "Comprehension", "Writing"]
    }
    return topics.get(subject.lower(), ["No recommendations available"])
